package com.example.ecommerceapp.Repository;

public interface PaymentRepo {
}
