package com.example.ecommerceapp.Security;

public @interface EnableWebSecurity {
}
