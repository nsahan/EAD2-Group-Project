package com.example.emaillogin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmailloginApplicationTests {

	@Test
	void contextLoads() {
	}

}
